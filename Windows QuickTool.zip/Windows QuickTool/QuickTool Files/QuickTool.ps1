﻿clear
Write-Host ""
Write-Host ""
Write-Host "Make sure you have fully read README.txt before counting, otherwise you might delete or install something 
you didn't intend too."
Read-Host "Press any key to continue"
clear
Read-Host "Welcome to Windows Quicktool, Once you're ready please press any key to continue:"
Set-ExecutionPolicy unrestricted
clear
Write-Host "Step 1: Removing Windows Tracking & Telementary"
Write-Host "Info: In this stage, we will change registery keys to stop windows from tracking & spying on you
it may output saying certain key's don't exist, that just means you don't have some pre-built in programs installed"
Write-Host ""
Read-Host "Press any key to continue"

Function ChangeReg {
  param ([string] $RegKey,
         [string] $Value,
         [string] $SvcName,
         [Int] $CheckValue,
         [Int] $SetData)
  Write-Host "Checking if $SvcName is enabled" -ForegroundColor Green
  if (!(Test-Path $RegKey)){
      Write-Host "Registry Key for service $SvcName does not exist, creating it now" -ForegroundColor Yellow
      New-Item -Path (Split-Path $RegKey) -Name (Split-Path $RegKey -Leaf) 
     }
 $ErrorActionPreference = 'Stop'
 try{
      #Get-ItemProperty -Path $RegKey -Name $Value 
      if((Get-ItemProperty -Path $RegKey -Name $Value).$Value -eq $CheckValue) {
          Write-Host "$SvcName is enabled, disabling it now" -ForegroundColor Green
          Set-ItemProperty -Path $RegKey -Name $Value -Value $SetData -Force
         }
      if((Get-ItemProperty -Path $RegKey -Name $Value).$Value -eq $SetData){
             Write-Host "$SvcName is disabled" -ForegroundColor Green
         }
     } catch [System.Management.Automation.PSArgumentException] {
       Write-Host "Registry entry for service $SvcName doesn't exist, creating and setting to disable now" -ForegroundColor Yellow
       New-ItemProperty -Path $RegKey -Name $Value -Value $SetData -Force
      }
   }
  
 # Disabling Advertising ID
 $RegKey = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\AdvertisingInfo"
 $Value = "Enabled"
 $SvcName = "Advertising ID"
 $CheckValue = 1
 $SetData = 0
 ChangeReg -RegKey $RegKey -Value $Value -SvcName $SvcName -CheckValue $CheckValue -SetData $SetData
 #Telemetry Disable
 $RegKey = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection"
 $Value = "AllowTelemetry"
 $SvcName = "Telemetry"
 $CheckValue = 1
 $SetData = 0        
 ChangeReg -RegKey $RegKey -Value $Value -SvcName $SvcName -CheckValue $CheckValue -SetData $SetData        
 #SmartScreen Disable
 $RegKey = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\AppHost"
 $Value = "EnableWebContentEvaluation"
 $SvcName = "Smart Screen"
 $CheckValue = 1
 $SetData = 0
 ChangeReg -RegKey $RegKey -Value $Value -SvcName $SvcName -CheckValue $CheckValue -SetData $SetData
 #Disable sending MS Inking and Typing Information
 $RegKey = "HKCU:\SOFTWARE\Microsoft\Input\TIPC"
 $Value = "Enabled"
 $SvcName = "Improve Inking and Typing Recognition"
 $CheckValue = 1
 $SetData = 0
 ChangeReg -RegKey $RegKey -Value $Value -SvcName $SvcName -CheckValue $CheckValue -SetData $SetData
 Write-Host "Disabling DiagTrack Services" -ForegroundColor Green 
 Get-Service -Name DiagTrack | Set-Service -StartupType Disabled | Stop-Service
 Get-Service -Name dmwappushservice | Set-Service -StartupType Disabled | Stop-Service
 Write-Host "DiagTrack Services are disabled" -ForegroundColor Green 
 Write-Host "Disabling telemetry scheduled tasks:" -ForegroundColor Green
 $tasks ="SmartScreenSpecific","ProgramDataUpdater","Microsoft Compatibility Appraiser","AitAgent","Proxy","Consolidator",
         "KernelCeipTask","BthSQM","CreateObjectTask","Microsoft-Windows-DiskDiagnosticDataCollector","WinSAT",
         "GatherNetworkInfo","FamilySafetyMonitor","FamilySafetyRefresh","SQM data sender","OfficeTelemetryAgentFallBack",
         "OfficeTelemetryAgentLogOn"
 $ErrorActionPreference = 'Stop'
 $tasks | %{
    try{
	   if (Get-ScheduledTask -TaskName $_ -ErrorAction Ignore){
       # This is get followed by disable to work-around a problem of disable task with embedded blanks in the name
       Get-ScheduledTask -TaskName $_ | Disable-ScheduledTask | Out-Null
       Write-Host "Task $_ disabled." -ForegroundColor Green
	   }
	   else {
	   Write-Host "Task $_ does not exist." -ForegroundColor yellow
	   }
       } catch { 
         # [Microsoft.PowerShell.Cmdletization.Cim.CimJobException]
         Write-Host "Task $($_.TargetObject) is not found" -ForegroundColor Yellow
       }
 }

Write-Host ""
Write-Host ""
Write-Host "Successfully Completed Step 1"
Read-Host "Press any key to continue"
clear
Write-Host "Step 2: Removing Bloatware"
Write-Host "Info: In this step we will remove annoying apps pre-loaded in windows that take up space,
Credit to ShadowWhisperer on github for the edge unistaller script :)"
Read-Host "Press any key to continue"
Write-Host ""
Write-Host "Opening Unistall Edge Script..."
Read-Host "Press any key to continue"
ii "C:\Users\Luca\Desktop\Windows QuickTool\QuickTool Files\removeedge startup.lnk"
Write-Host "..."
Read-Host "Press any key to continue"