Welcome to QuickTool and thank you for downloading!
This script is meant for virtual machines or brand new machines, its purpose installs useful- basic programs, 
removes windows tracking features & unistalls bloatware of your system. 
This is not intended for already used computers unless you know what your doing.
Note: This Tool is intended for Windows 10 & has been tested and made with that, It might work
in other versions of windows but I am unsure how it will act or work.

- Storage -
525mb of storage will be added from programs
156mb of storage will be removed from programs*

- Programs that will be added -
These programs are basic utility programs for general use that's used for everyday use-
- Firefox/Chrome (depending on what script you choose)
- 7zip
- Thunderbird
- VLC media player

- Registery Editors -
Minor changes have been made too the registery editor to stop
corruption that much in case of a freak accident so not all
- Will Disable Advertising ID
- Will Disable Telementary
- Will Disable "Required" Dignostic Data
- Will Disable all other misc Opitinal Data Collection in setup

- Removed Bloatware -
(I kept microsoft store as some people find it very useful and can be used to reinstall software i unistall, there is a script that removes it in the "Extra's
& Other Utilites" Folder.)
- Removes XBOX & related software
- Removes Microsoft Edge
- Removes Windows Mail
- Removes My Phone
- Removes People App
- Removes
- as well as removing some other minor things (such as advertising)